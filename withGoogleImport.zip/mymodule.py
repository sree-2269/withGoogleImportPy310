# mymodule.py

# Define a class called MyClass1
class MyClass1:
    def __init__(self):
        self.name = "MyClass1"

    def some_method(self):
        print(f"{self.name} is doing something.")

# Define another class called MyClass2
class MyClass2:
    def __init__(self):
        self.name = "MyClass2"

    def some_method(self):
        print(f"{self.name} is doing something else.")
